﻿namespace QAction_2
{
    public class QAction_2
    {
    }
}
