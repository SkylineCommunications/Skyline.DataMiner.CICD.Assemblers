﻿namespace SharedProject
{
	public class SharedCode
	{
		public bool TestSharedCall()
		{
			return true;
		}
	}
}
