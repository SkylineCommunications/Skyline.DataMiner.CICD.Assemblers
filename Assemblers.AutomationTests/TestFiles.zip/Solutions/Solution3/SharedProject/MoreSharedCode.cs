﻿namespace SharedProject
{
	using System.Threading;

	public class UnusedSharedCode
	{
		public void JustAnotherCall()
		{
			Thread.Sleep(100);
		}
	}
}
