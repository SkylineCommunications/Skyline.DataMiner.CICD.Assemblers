namespace MyUtils
{
	public static class Utils
	{
		public static string MakeUppercase(string input)
		{
			return input.ToUpper();
		}
	}
}